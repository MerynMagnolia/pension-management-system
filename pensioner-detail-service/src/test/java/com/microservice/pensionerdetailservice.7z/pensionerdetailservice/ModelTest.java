package com.microservice.pensionerdetailservice;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;

class ModelTest {
	
	@Mock
	PensionerDetail pensionerDetail;

	@Test
	void testNoArgsBankDetailTest() {
		assertThat(new BankDetail()).isNotNull();
	}

	@Test
	void testAllArgsBankDetailTest() {
		BankDetail bankDetails = new BankDetail("SBI", "1234567890", "Private");
		assertNotNull(bankDetails);
	}

	@Test
	void testSetterBankTest() {
		BankDetail b = new BankDetail();
		b.setAccountNumber("S00101");
		b.setBankName("SBI");
		b.setBankType("public");
		assertThat(assertThat(b).isNotNull());
	}

	@Test
	void SetterArgsBankDetailTest() {
		BankDetail bankDetails = new BankDetail("SBI", "1234567890", "private");
		assertEquals("SBI", bankDetails.getBankName());
		assertEquals("1234567890", bankDetails.getAccountNumber());
		assertEquals("private", bankDetails.getBankType());
	}

	@Test
	void testSetterPensionerDetailTest() {
		pensionerDetail.setId(100L);
		pensionerDetail.setPensionerName("Justin");
		pensionerDetail.setAadharNumber(948820870619L);
		pensionerDetail.setDob(new Date());
		pensionerDetail.setPan("GTYIK7412L");
		pensionerDetail.setLastSalary(10000);
		pensionerDetail.setAllowances(500);
		pensionerDetail.setPensionType("family");

		BankDetail bankDetail = new BankDetail();
		bankDetail.setAccountNumber("102233445566");
		bankDetail.setBankName("SBI");
		bankDetail.setBankType("public");

//		pensionerDetail.setBankDetail(bankDetail);
		assertThat(assertThat(pensionerDetail).isNotNull());

		assertEquals(100L, pensionerDetail.getId());
		assertEquals("Justin", pensionerDetail.getPensionerName());
		assertEquals(948820870619L, pensionerDetail.getAadharNumber());
		assertEquals(new Date(), pensionerDetail.getDob());
		assertEquals("GTYIK7412L", pensionerDetail.getPan()) ;
		assertEquals(10000, pensionerDetail.getLastSalary()) ;
		assertEquals(500, pensionerDetail.getAllowances());
		assertEquals("family", pensionerDetail.getPensionType());

		assertEquals("102233445566", bankDetail.getAccountNumber());
		assertEquals("SBI", bankDetail.getBankName());
		assertEquals("public", bankDetail.getBankType());

	}

}
