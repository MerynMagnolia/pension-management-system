package com.microservice.pensionerdetailservice;

import static org.junit.Assert.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.CALLS_REAL_METHODS;
import static org.mockito.Mockito.when;

import java.util.Date;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;

@ExtendWith(MockitoExtension.class)
//@RunWith(JUnitPlatform.class)
class PensionerDetailTest {

	@InjectMocks
	PensionerDetailController pensionerDetailController;

	@Mock
	PensionerDetailRepository pensionerDetailRepo;

	@Mock
	PensionerDetail pensionerDetail;

	@Test
	public void retrievePensionerDetailTest() {

		PensionerDetail p = new PensionerDetail(100L, "Justin", 948820870619L, new Date(), "GTYIK7412L", 10000, 550,
				"family", "102233445566", "SBI", "public", 0L, "");
		when(pensionerDetailRepo.findByAadharNumber(948820870619L)).thenReturn(pensionerDetail);
		assertEquals(10000, pensionerDetail.getLastSalary()) ;
		assertEquals(550, pensionerDetail.getAllowances());	
	}
}
