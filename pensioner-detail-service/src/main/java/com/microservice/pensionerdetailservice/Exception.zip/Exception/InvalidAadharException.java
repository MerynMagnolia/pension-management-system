package com.microservice.pensionerdetailservice.Exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class InvalidAadharException extends PensionException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidAadharException(String msg) {
		super(msg, "Aadhar not found");
	}
}
